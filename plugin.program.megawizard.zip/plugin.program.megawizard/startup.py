# -*- coding: utf-8 -*-
################################################################################
#      Copyright (C) 2019 drinfernoo                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import os
import sys
import time
import traceback

import xbmc
import xbmcgui

try:  # Python 3
    from urllib.parse import quote_plus
except ImportError:  # Python 2 (legacy)
    from urllib import quote_plus

# Projekt-Imports
from resources.libs.common.config import CONFIG
from resources.libs import clear, check, db, skin, update
from resources.libs.gui import window
from resources.libs.common import logging, tools


LOGINFO  = getattr(xbmc, "LOGINFO", xbmc.LOGINFO)
LOGERROR = getattr(xbmc, "LOGERROR", xbmc.LOGINFO)
LOGWARN  = getattr(xbmc, "LOGWARNING", xbmc.LOGINFO)


def log(msg, lvl=LOGINFO):
    try:
        xbmc.log(f"[{CONFIG.ADDON_ID}][startup] {msg}", lvl)
    except Exception:
        pass


def wait_until_home(monitor, max_seconds=30):
    start = time.time()
    while not monitor.abortRequested():
        if xbmc.getCondVisibility("Window.IsActive(home)"):
            return True
        if time.time() - start > max_seconds:
            return False
        monitor.waitForAbort(0.25)
    return False


def wait_while_video_playing(monitor, max_seconds=120):
    start = time.time()
    while not monitor.abortRequested() and xbmc.Player().isPlayingVideo():
        if time.time() - start > max_seconds:
            log("Timeout while waiting for video to stop", LOGWARN)
            return False
        monitor.waitForAbort(0.5)
    return True


def safe_open_url(url, check_only=False):
    """
    Ruft tools.open_url() robust auf und akzeptiert sowohl Rückgabe als Text
    als auch requests.Response. Bei check_only wird nur True/False geliefert.
    """
    try:
        resp = tools.open_url(url, check=check_only)
        if check_only:
            return bool(resp)
        # resp kann String ODER Response sein
        if hasattr(resp, "text"):
            return resp.text
        return resp  # already str/bytes
    except Exception:
        log("open_url failed:\n" + traceback.format_exc(), LOGERROR)
        return "" if not check_only else False


def auto_install_repo(monitor):
    try:
        repo_path = os.path.join(CONFIG.ADDONS, CONFIG.REPOID)
        if os.path.exists(repo_path):
            log("[Auto Install Repo] Repository already installed")
            return

        # addons.xml des Repos lesen
        xml_text = safe_open_url(CONFIG.REPOADDONXML, check_only=False)
        if not xml_text:
            logging.log_notify("[COLOR {0}]Repo Install Error[/COLOR]".format(CONFIG.COLOR1),
                               "[COLOR {0}]Invalid addon.xml file![/COLOR]".format(CONFIG.COLOR2))
            log("[Auto Install Repo] Unable to read the addon.xml file.", LOGERROR)
            return

        from xml.etree import ElementTree as ET
        try:
            root = ET.fromstring(xml_text)
        except Exception:
            log("[Auto Install Repo] addons.xml parse error:\n" + traceback.format_exc(), LOGERROR)
            return

        repoversion = [tag.get('version') for tag in root.findall('addon') if tag.get('id') == CONFIG.REPOID]
        if not repoversion:
            log("[Auto Install Repo] Repo ID not found in addons.xml", LOGERROR)
            return

        installzip = f"{CONFIG.REPOID}-{repoversion[0]}.zip"
        base = CONFIG.REPOZIPURL.rstrip('/') + '/'
        zip_url = base + installzip

        if not safe_open_url(zip_url, check_only=True):
            logging.log_notify("[COLOR {0}]Repo Install Error[/COLOR]".format(CONFIG.COLOR1),
                               "[COLOR {0}]Invalid URL for zip![/COLOR]".format(CONFIG.COLOR2))
            log(f"[Auto Install Repo] Invalid ZIP URL: {zip_url}", LOGERROR)
            return

        # Download & Entpacken
        tools.ensure_folders(CONFIG.PACKAGES)
        lib = os.path.join(CONFIG.PACKAGES, installzip)
        tools.remove_file(lib)

        from resources.libs.downloader import Downloader
        from resources.libs import extract

        progress = xbmcgui.DialogProgress()
        try:
            progress.create(CONFIG.ADDONTITLE, "Downloading Repo...\nPlease Wait")
            Downloader().download(zip_url, lib)
            if monitor.abortRequested():
                log("[Auto Install Repo] Aborted by user/Kodi", LOGWARN)
                return
            extract.all(lib, CONFIG.ADDONS)
        finally:
            try:
                progress.close()
            except Exception:
                pass

        # Name aus addon.xml des Repos loggen
        try:
            repoxml = os.path.join(CONFIG.ADDONS, CONFIG.REPOID, 'addon.xml')
            from xml.etree import ElementTree as ET2
            rname = ET2.parse(repoxml).getroot().get('name')
            logging.log_notify("{0}".format(rname),
                               "[COLOR {0}]Add-on updated[/COLOR]".format(CONFIG.COLOR2),
                               icon=os.path.join(CONFIG.ADDONS, CONFIG.REPOID, 'icon.png'))
        except Exception:
            log("[Auto Install Repo] Post-install read failed:\n" + traceback.format_exc(), LOGWARN)

        db.addon_database(CONFIG.REPOID, 1)
        log("[Auto Install Repo] Successfully Installed")

    except Exception:
        log("[Auto Install Repo] Unexpected error:\n" + traceback.format_exc(), LOGERROR)


def show_notification():
    try:
        note_id, msg = window.split_notify(CONFIG.NOTIFICATION)
        if not note_id:
            log('[Notifications] Invalid format: {0}'.format(CONFIG.NOTIFICATION), LOGINFO)
            return

        if note_id == CONFIG.NOTEID:
            if CONFIG.NOTEDISMISS == 'false':
                window.show_notification(msg)
            else:
                log('[Notifications] No new notifications.', LOGINFO)
        elif note_id > CONFIG.NOTEID:
            log('[Notifications] Showing notification {0}'.format(note_id), LOGINFO)
            CONFIG.set_setting('noteid', note_id)
            CONFIG.set_setting('notedismiss', 'false')
            window.show_notification(msg)
    except Exception:
        log("[Notifications] Error:\n" + traceback.format_exc(), LOGERROR)


def installed_build_check():
    try:
        dialog = xbmcgui.Dialog()

        if not CONFIG.EXTRACT == '100' and CONFIG.EXTERROR > 0:
            log("[Build Installed Check] Extract {0}/100, ERRORS: {1}".format(CONFIG.EXTRACT, CONFIG.EXTERROR), LOGINFO)
            yes = dialog.yesno(
                CONFIG.ADDONTITLE,
                '[COLOR {0}]{2}[/COLOR] [COLOR {1}]was not installed correctly![/COLOR]'.format(
                    CONFIG.COLOR1, CONFIG.COLOR2, CONFIG.BUILDNAME),
                ('Installed: [COLOR {0}]{1}[/COLOR] / Error Count: [COLOR {2}]{3}[/COLOR]').format(
                    CONFIG.COLOR1, CONFIG.EXTRACT, CONFIG.COLOR1, CONFIG.EXTERROR),
                'Would you like to try again?[/COLOR]',
                nolabel='[B]No Thanks![/B]',
                yeslabel='[B]Retry Install[/B]'
            )
            CONFIG.clear_setting('build')
            if yes:
                xbmc.executebuiltin("PlayMedia(plugin://{0}/?mode=install&name={1}&url=fresh)".format(
                    CONFIG.ADDON_ID, quote_plus(CONFIG.BUILDNAME)))
                log("[Build Installed Check] Fresh Install Re-activated", LOGINFO)
            else:
                log("[Build Installed Check] Reinstall Ignored", LOGINFO)

        elif CONFIG.SKIN in ['skin.confluence', 'skin.estuary', 'skin.estouchy']:
            log("[Build Installed Check] Incorrect skin: {0}".format(CONFIG.SKIN), LOGINFO)
            defaults = CONFIG.get_setting('defaultskin')
            if defaults and os.path.exists(os.path.join(CONFIG.ADDONS, defaults)):
                if skin.skin_to_default(defaults):
                    skin.look_and_feel_data('restore')

            if CONFIG.SKIN != defaults and CONFIG.BUILDNAME:
                gui_xml = check.check_build(CONFIG.BUILDNAME, 'gui')
                if not tools.open_url(gui_xml, check=True):
                    log("[Build Installed Check] No GUI fix attached", LOGINFO)
                    dialog.ok(
                        CONFIG.ADDONTITLE,
                        "[COLOR {0}]It looks like the skin settings were not applied.[/COLOR]".format(CONFIG.COLOR2),
                        "No GUI fix found.",
                        "Reinstall the build and force close."
                    )
                else:
                    yes = dialog.yesno(
                        CONFIG.ADDONTITLE,
                        '{0} was not installed correctly!'.format(CONFIG.BUILDNAME),
                        'Skin settings not applied.',
                        'Apply GUI fix now?',
                        nolabel='[B]No, Cancel[/B]', yeslabel='[B]Apply Fix[/B]'
                    )
                    if yes:
                        xbmc.executebuiltin("PlayMedia(plugin://{0}/?mode=install&name={1}&url=gui)".format(
                            CONFIG.ADDON_ID, quote_plus(CONFIG.BUILDNAME)))
                        log("[Build Installed Check] GUI fix installing", LOGINFO)
                    else:
                        log('[Build Installed Check] GUI fix cancelled: {0}'.format(gui_xml), LOGINFO)
        else:
            log('[Build Installed Check] Install seems OK', LOGINFO)

        if CONFIG.get_setting('installed') == 'true':
            if CONFIG.get_setting('keeptrakt') == 'true':
                from resources.libs import traktit
                log('[Build Installed Check] Restoring Trakt Data', LOGINFO)
                traktit.trakt_it('restore', 'all')
            if CONFIG.get_setting('keepdebrid') == 'true':
                from resources.libs import debridit
                log('[Build Installed Check] Restoring Real Debrid Data', LOGINFO)
                debridit.debrid_it('restore', 'all')
            if CONFIG.get_setting('keeplogin') == 'true':
                from resources.libs import loginit
                log('[Build Installed Check] Restoring Login Data', LOGINFO)
                loginit.login_it('restore', 'all')

            CONFIG.clear_setting('install')

    except Exception:
        log("[Build Installed Check] Error:\n" + traceback.format_exc(), LOGERROR)


def build_update_check():
    try:
        if not tools.open_url(CONFIG.BUILDFILE, check=True):
            log("[Build Check] Invalid Build File URL: {0}".format(CONFIG.BUILDFILE), LOGINFO)
            return

        if CONFIG.BUILDNAME:
            if CONFIG.SKIN in ['skin.confluence', 'skin.estuary', 'skin.estouchy'] and CONFIG.DEFAULTIGNORE != 'true':
                check.check_skin()
            log("[Build Check] Build Installed: Checking Updates", LOGINFO)
            check.check_build_update()

        CONFIG.set_setting('nextbuildcheck', tools.get_date(days=CONFIG.UPDATECHECK, formatted=True))
    except Exception:
        log("[Build Check] Error:\n" + traceback.format_exc(), LOGERROR)


def timed_save(helper_module_name, setting_key, label):
    try:
        current_time = time.mktime(time.strptime(tools.get_date(formatted=True), "%Y-%m-%d %H:%M:%S"))
        next_save = time.mktime(time.strptime(CONFIG.get_setting(setting_key), "%Y-%m-%d %H:%M:%S"))
        if next_save <= current_time:
            mod = __import__(f"resources.libs.{helper_module_name}", fromlist=['*'])
            log(f"[{label}] Saving all Data", LOGINFO)
            mod.auto_update('all')
            CONFIG.set_setting(setting_key, tools.get_date(days=3, formatted=True))
        else:
            log(f"[{label}] Next Auto Save: {CONFIG.get_setting(setting_key)} / TODAY: {tools.get_date(formatted=True)}", LOGINFO)
    except Exception:
        log(f"[{label}] Error:\n" + traceback.format_exc(), LOGERROR)


def auto_clean():
    try:
        service = False
        days = [
            tools.get_date(formatted=True),
            tools.get_date(days=1, formatted=True),
            tools.get_date(days=3, formatted=True),
            tools.get_date(days=7, formatted=True),
            tools.get_date(days=30, formatted=True),
        ]

        freq = int(CONFIG.AUTOFREQ)
        next_cleanup = time.mktime(time.strptime(CONFIG.NEXTCLEANDATE, "%Y-%m-%d %H:%M:%S"))

        if next_cleanup <= tools.get_date() or freq == 0:
            service = True
            CONFIG.set_setting('nextautocleanup', days[freq])
        else:
            log("[Auto Clean Up] Next Clean Up {0}".format(CONFIG.NEXTCLEANDATE), LOGINFO)

        if not service:
            return

        if CONFIG.AUTOCACHE == 'true':
            log('[Auto Clean Up] Cache: On', LOGINFO)
            clear.clear_cache(True)
        else:
            log('[Auto Clean Up] Cache: Off', LOGINFO)

        if CONFIG.AUTOTHUMBS == 'true':
            log('[Auto Clean Up] Old Thumbs: On', LOGINFO)
            clear.old_thumbs()
        else:
            log('[Auto Clean Up] Old Thumbs: Off', LOGINFO)

        if CONFIG.AUTOPACKAGES == 'true':
            log('[Auto Clean Up] Packages: On', LOGINFO)
            clear.clear_packages_startup()
        else:
            log('[Auto Clean Up] Packages: Off', LOGINFO)
    except Exception:
        log("[Auto Clean Up] Error:\n" + traceback.format_exc(), LOGERROR)


def main():
    monitor = xbmc.Monitor()

    # Warten bis Home aktiv ist (und ggf. Video beendet ist)
    wait_until_home(monitor, max_seconds=30)
    if not wait_while_video_playing(monitor, max_seconds=120):
        log("Proceeding despite video playback timeout", LOGWARN)

    if monitor.abortRequested():
        log("Aborted before start", LOGWARN)
        return

    # Ensure needed folders / sanity checks
    try:
        tools.ensure_folders()
        check.check_paths()
    except Exception:
        log("ensure_folders/check_paths failed:\n" + traceback.format_exc(), LOGERROR)

    # FIRST RUN SETTINGS
    try:
        if CONFIG.get_setting('first_install') == 'true':
            log("[First Run] Showing Save Data Settings", LOGINFO)
            window.show_save_data_settings()
        else:
            log("[First Run] Skipping Save Data Settings", LOGINFO)
    except Exception:
        log("[First Run] Error:\n" + traceback.format_exc(), LOGERROR)

    # BUILD INSTALL PROMPT
    try:
        if tools.open_url(CONFIG.BUILDFILE, check=True) and CONFIG.get_setting('installed') == 'false':
            log("[Current Build Check] Build Not Installed", LOGINFO)
            window.show_build_prompt()
        else:
            log("[Current Build Check] Build Installed: {0}".format(CONFIG.BUILDNAME), LOGINFO)
    except Exception:
        log("[Current Build Check] Error:\n" + traceback.format_exc(), LOGERROR)

    # BUILD UPDATE CHECK (nach Zeitplan)
    try:
        buildcheck = CONFIG.get_setting('nextbuildcheck')
        if CONFIG.get_setting('buildname'):
            current_time = time.time()
            epoch_check = time.mktime(time.strptime(buildcheck, "%Y-%m-%d %H:%M:%S"))
            if current_time >= epoch_check:
                log("[Build Update Check] Started", LOGINFO)
                build_update_check()
        else:
            log("[Build Update Check] Next Check: {0}".format(buildcheck), LOGINFO)
    except Exception:
        log("[Build Update Check] Error:\n" + traceback.format_exc(), LOGERROR)

    # AUTO INSTALL REPO
    try:
        if CONFIG.AUTOINSTALL == 'Yes':
            log("[Auto Install Repo] Started", LOGINFO)
            auto_install_repo(monitor)
        else:
            log("[Auto Install Repo] Not Enabled", LOGINFO)
    except Exception:
        log("[Auto Install Repo] Error:\n" + traceback.format_exc(), LOGERROR)

    # REINSTALL ELIGIBLE BINARIES
    try:
        binarytxt = os.path.join(CONFIG.USERDATA, 'build_binaries.txt')
        if os.path.exists(binarytxt):
            log("[Binary Detection] Reinstalling Eligible Binary Addons", LOGINFO)
            from resources.libs import restore
            restore.restore('binaries')
        else:
            log("[Binary Detection] No binaries to reinstall", LOGINFO)
    except Exception:
        log("[Binary Detection] Error:\n" + traceback.format_exc(), LOGERROR)

    # AUTO UPDATE WIZARD
    try:
        if CONFIG.AUTOUPDATE == 'Yes':
            log("[Auto Update Wizard] Started", LOGINFO)
            update.wizard_update()
        else:
            log("[Auto Update Wizard] Not Enabled", LOGINFO)
    except Exception:
        log("[Auto Update Wizard] Error:\n" + traceback.format_exc(), LOGERROR)

    # SHOW NOTIFICATIONS
    try:
        if CONFIG.ENABLE_NOTIFICATION == 'Yes':
            show_notification()
        else:
            log('[Notifications] Not Enabled', LOGINFO)
    except Exception:
        log("[Notifications] Error:\n" + traceback.format_exc(), LOGERROR)

    # INSTALLED BUILD CHECK
    try:
        if CONFIG.get_setting('installed') == 'true':
            log("[Build Installed Check] Started", LOGINFO)
            installed_build_check()
        else:
            log("[Build Installed Check] Not Enabled", LOGINFO)
    except Exception:
        log("[Build Installed Check] Error:\n" + traceback.format_exc(), LOGERROR)

    # SAVE TASKS (Trakt / Debrid / Login)
    try:
        if CONFIG.get_setting('keeptrakt') == 'true':
            log("[Trakt Data] Started", LOGINFO)
            timed_save('traktit', 'traktnextsave', 'Trakt Data')
        else:
            log("[Trakt Data] Not Enabled", LOGINFO)
    except Exception:
        log("[Trakt Data] Error:\n" + traceback.format_exc(), LOGERROR)

    try:
        if CONFIG.get_setting('keepdebrid') == 'true':
            log("[Debrid Data] Started", LOGINFO)
            timed_save('debridit', 'debridnextsave', 'Debrid Data')
        else:
            log("[Debrid Data] Not Enabled", LOGINFO)
    except Exception:
        log("[Debrid Data] Error:\n" + traceback.format_exc(), LOGERROR)

    try:
        if CONFIG.get_setting('keeplogin') == 'true':
            log("[Login Info] Started", LOGINFO)
            timed_save('loginit', 'loginnextsave', 'Login Info')
        else:
            log("[Login Info] Not Enabled", LOGINFO)
    except Exception:
        log("[Login Info] Error:\n" + traceback.format_exc(), LOGERROR)

    # AUTO CLEAN
    try:
        if CONFIG.get_setting('autoclean') == 'true':
            log("[Auto Clean Up] Started", LOGINFO)
            auto_clean()
        else:
            log('[Auto Clean Up] Not Enabled', LOGINFO)
    except Exception:
        log("[Auto Clean Up] Error:\n" + traceback.format_exc(), LOGERROR)

    log("Service finished", LOGINFO)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        xbmc.log("[startup] Unexpected fatal error:\n" + traceback.format_exc(), LOGERROR)
        sys.exit(0)