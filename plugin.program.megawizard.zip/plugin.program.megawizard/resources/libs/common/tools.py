# -*- coding: utf-8 -*-
"""
tools.py – Helper utilities for MegaWizard

- Kein Pflicht-Dependency auf requests (Fallback via urllib)
- Verhindert Hänger dank Timeouts/Retries
- API:
    open_url(url, check=True)  -> bool
    open_url(url, check=False) -> Response-ähnliches Objekt oder None
- Utils: ensure_folders, remove_file, read_from_file, write_to_file, get_date, platform, clean_text
"""

import os
import io
import sys
import re
import html
import time
from datetime import datetime, timedelta

import xbmc

# Pfadübersetzung
try:
    import xbmcvfs
    def _xlate(p): return xbmcvfs.translatePath(p)
except Exception:
    def _xlate(p): return p

# Logging-Levels (Kodi 19+)
try:
    LOGINFO = xbmc.LOGINFO
    LOGERROR = xbmc.LOGERROR
    LOGWARNING = xbmc.LOGWARNING
except Exception:
    LOGINFO, LOGERROR, LOGWARNING = 1, 3, 2

def _log(msg, lvl=LOGINFO):
    try:
        xbmc.log(f"[tools] {msg}", lvl)
    except Exception:
        pass

# Optional CONFIG
try:
    from resources.libs.common.config import CONFIG
except Exception:
    CONFIG = None

# ---------------------------------------------------------------------
# HTTP: requests (optional) mit urllib-Fallback
# ---------------------------------------------------------------------
HTTP_TIMEOUT = (5, 25)
_UA = "Kodi-MegaWizard/1.0"
if CONFIG and getattr(CONFIG, "USER_AGENT", None):
    _UA = CONFIG.USER_AGENT

# Response-Wrapper (vereinheitlicht für requests/urllib)
class _Resp:
    def __init__(self, url="", status=0, headers=None, content=b""):
        self.url = url
        self.status_code = status
        self.headers = headers or {}
        self.content = content
        try:
            self.text = content.decode("utf-8", "replace")
        except Exception:
            self.text = ""
    def raise_for_status(self):
        if not (200 <= int(self.status_code) < 400):
            raise Exception(f"HTTP {self.status_code} for {self.url}")
    def close(self):  # für API-Kompatibilität
        pass

# Versuche requests zu laden; fallback auf urllib
try:
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry

    _session = None
    def _get_session():
        global _session
        if _session is None:
            s = requests.Session()
            # Kompatibel zu älterem urllib3 (allowed_methods vs method_whitelist)
            retry_kwargs = dict(
                total=3, connect=3, read=3,
                backoff_factor=0.8,
                status_forcelist=(429, 500, 502, 503, 504),
            )
            try:
                retry = Retry(allowed_methods=frozenset(("GET","HEAD")), **retry_kwargs)
            except TypeError:
                retry = Retry(method_whitelist=frozenset(("GET","HEAD")), **retry_kwargs)
            s.headers.update({"User-Agent": _UA, "Accept-Encoding": "gzip, deflate, br"})
            adapter = HTTPAdapter(max_retries=retry, pool_connections=8, pool_maxsize=16)
            s.mount("https://", adapter)
            s.mount("http://", adapter)
            _session = s
        return _session

    def _req_get(url, timeout, headers, allow_redirects, auth):
        s = _get_session()
        return s.get(url, timeout=timeout or HTTP_TIMEOUT, headers=headers or {},
                     allow_redirects=allow_redirects, auth=auth, stream=False)

    def _req_head(url, timeout):
        s = _get_session()
        return s.head(url, timeout=timeout, allow_redirects=True)

    _USING_REQUESTS = True

except Exception:
    # urllib-Fallback (kein externes Modul nötig)
    import urllib.request, urllib.error

    class _Opener:
        def __init__(self):
            handlers = [urllib.request.HTTPRedirectHandler()]
            self.opener = urllib.request.build_opener(*handlers)
            self.headers = {"User-Agent": _UA}

        def _request(self, url, method="GET", timeout=HTTP_TIMEOUT):
            req = urllib.request.Request(url, method=method, headers=self.headers)
            with self.opener.open(req, timeout=(timeout[0] if isinstance(timeout, tuple) else timeout)) as r:
                status = getattr(r, "status", 200)
                headers = dict(r.getheaders())
                data = r.read() if method != "HEAD" else b""
                return _Resp(url=url, status=status, headers=headers, content=data)

    _opener = _Opener()

    def _req_get(url, timeout, headers, allow_redirects, auth):
        # headers/auth/redirects minimal unterstützt
        if headers: _opener.headers.update(headers)
        return _opener._request(url, "GET", timeout or HTTP_TIMEOUT)

    def _req_head(url, timeout):
        return _opener._request(url, "HEAD", timeout or 10)

    _USING_REQUESTS = False

def check_url(url, timeout=10):
    """HEAD mit Fallback GET – True bei 2xx/3xx."""
    try:
        try:
            r = _req_head(url, timeout)
            if 200 <= int(r.status_code) < 400:
                return True
        except Exception:
            pass
        r = _req_get(url, timeout, headers=None, allow_redirects=True, auth=None)
        return (200 <= int(getattr(r, "status_code", 0)) < 400)
    except Exception as e:
        _log(f"check_url failed for {url}: {e}", LOGWARNING)
        return False

def open_url(url, check=False, timeout=None, headers=None, allow_redirects=True, auth=None):
    """
    - check=True  -> bool (Erreichbarkeit)
    - check=False -> Response-ähnliches Objekt (_Resp oder requests.Response) oder None
    """
    if check:
        return check_url(url, timeout=timeout or 10)
    try:
        r = _req_get(url, timeout, headers, allow_redirects, auth)
        # Bei urllib-Fallback bekommen wir bereits _Resp; bei requests Response
        if hasattr(r, "raise_for_status"):
            r.raise_for_status()
        return r
    except Exception as e:
        _log(f"open_url failed for {url}: {e}", LOGWARNING)
        return None

# ---------------------------------------------------------------------
# Datei-/Pfad-Utils
# ---------------------------------------------------------------------
def ensure_folders(*paths):
    to_make = list(paths)
    if not to_make and CONFIG:
        for attr in ("PACKAGES","USERDATA","ADDONS","LOGPATH","DATABASE","INSTALL","TMP"):
            p = getattr(CONFIG, attr, None)
            if isinstance(p, str) and p:
                to_make.append(p)
    made = []
    for p in to_make:
        try:
            abspath = _xlate(p)
            os.makedirs(abspath, exist_ok=True)
            made.append(abspath)
        except Exception as e:
            _log(f"ensure_folders failed for {p}: {e}", LOGWARNING)
    return made

def remove_file(path):
    try:
        p = _xlate(path)
        if os.path.exists(p):
            os.remove(p)
        return not os.path.exists(p)
    except Exception as e:
        _log(f"remove_file failed for {path}: {e}", LOGWARNING)
        return False

def read_from_file(path, binary=False):
    p = _xlate(path)
    try:
        if binary:
            with open(p, "rb") as f:
                return f.read()
        else:
            with io.open(p, "r", encoding="utf-8", errors="replace") as f:
                return f.read()
    except Exception as e:
        _log(f"read_from_file failed for {path}: {e}", LOGWARNING)
        return b"" if binary else ""

def write_to_file(path, data, mode='w'):
    p = _xlate(path)
    try:
        os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
        if 'b' in mode:
            if isinstance(data, str):
                data = data.encode('utf-8', 'replace')
            with open(p, mode) as f:
                f.write(data)
        else:
            if not isinstance(data, str):
                data = data.decode('utf-8', 'replace') if isinstance(data, (bytes, bytearray)) else str(data)
            with io.open(p, mode, encoding="utf-8") as f:
                f.write(data)
        return True
    except Exception as e:
        _log(f"write_to_file failed for {path}: {e}", LOGWARNING)
        return False

# ---------------------------------------------------------------------
# Text-Helfer
# ---------------------------------------------------------------------
_KODI_TAGS_SIMPLE = re.compile(r'\[/?(B|I|LIGHT|UPPERCASE|LOWERCASE|CAPITALIZE)\]', re.IGNORECASE)
_KODI_COLOR_TAGS  = re.compile(r'\[/?COLOR[^\]]*\]', re.IGNORECASE)
_KODI_ALIGN_TAGS  = re.compile(r'\[/?ALIGN[^\]]*\]', re.IGNORECASE)

def clean_text(value):
    if value is None:
        return ""
    if isinstance(value, (bytes, bytearray)):
        try: value = value.decode("utf-8", "replace")
        except Exception: value = value.decode("latin-1", "replace")
    s = html.unescape(value)
    s = s.replace('\r\n','\n').replace('\r','\n').replace('[CR]','\n')
    s = _KODI_COLOR_TAGS.sub('', s)
    s = _KODI_TAGS_SIMPLE.sub('', s)
    s = _KODI_ALIGN_TAGS.sub('', s)
    s = re.sub(r'\n{3,}', '\n\n', s)
    s = re.sub(r'[^\x09\x0A\x0D\x20-\x7E\u00A0-\uFFFF]', '', s)
    return s.strip()

# ---------------------------------------------------------------------
# Zeit/Plattform
# ---------------------------------------------------------------------
def get_date(days=0, formatted=False):
    dt = datetime.now() + timedelta(days=days)
    if formatted:
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    return int(time.mktime(dt.timetuple()))

def platform():
    try:
        if xbmc.getCondVisibility('system.platform.android'): return 'android'
        if xbmc.getCondVisibility('system.platform.ios'):     return 'ios'
        if xbmc.getCondVisibility('system.platform.osx'):     return 'osx'
        if xbmc.getCondVisibility('system.platform.uwp'):     return 'uwp'
        if xbmc.getCondVisibility('system.platform.windows'): return 'windows'
        if xbmc.getCondVisibility('system.platform.linux'):   return 'linux'
    except Exception:
        pass
    if sys.platform.startswith('win'):    return 'windows'
    if sys.platform.startswith('linux'):  return 'linux'
    if sys.platform.startswith('darwin'): return 'osx'
    return 'unknown'