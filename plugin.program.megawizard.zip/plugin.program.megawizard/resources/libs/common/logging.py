# -*- coding: utf-8 -*-
################################################################################
#      Copyright (C) 2019 drinfernoo                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.           #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import os
import re
import io
import time
import xbmc
import xbmcgui
import xbmcvfs
import _strptime  # noqa: F401

from resources.libs.common import tools
from resources.libs.common.config import CONFIG

try:  # Python 3
    from urllib.parse import urlencode
    from urllib.request import FancyURLopener
except ImportError:  # Python 2
    from urllib import urlencode
    from urllib import FancyURLopener

URL = 'https://paste.ubuntu.com/'
EXPIRATION = 2592000
REPLACES = (
    ('//.+?:.+?@', '//USER:PASSWORD@'),
    ('<user>.+?</user>', '<user>USER</user>'),
    ('<pass>.+?</pass>', '<pass>PASSWORD</pass>'),
)

def _translate_path(p):
    try:
        return xbmcvfs.translatePath(p)
    except Exception:
        return p

def log(msg, level=xbmc.LOGDEBUG):
    try:
        if CONFIG.DEBUGLEVEL == '0':  # No Logging
            return False
        if CONFIG.DEBUGLEVEL == '2':  # Full Logging
            level = getattr(xbmc, "LOGINFO", xbmc.LOGDEBUG)

        xbmc.log('{0}: {1}'.format(CONFIG.ADDONTITLE, msg), level)

        if CONFIG.ENABLEWIZLOG == 'true':
            log_path = _translate_path(CONFIG.WIZLOG)
            try:
                os.makedirs(os.path.dirname(log_path), exist_ok=True)
            except Exception:
                pass

            # Zeile zusammenbauen und sicher anhängen
            line = "[{0}] {1}".format(tools.get_date(formatted=True), msg).rstrip('\r\n') + '\n'
            try:
                with io.open(log_path, 'a', encoding='utf-8') as f:
                    f.write(line)
            except Exception:
                pass

        return True
    except Exception:
        # Logger darf nie zum Absturz führen
        return False

def check_log():
    try:
        log_path = _translate_path(CONFIG.WIZLOG)
        next_when = tools.get_date(days=1, formatted=True)
        content = tools.read_from_file(log_path) if os.path.exists(log_path) else ""
        lines = content.split('\n') if content else []

        if CONFIG.CLEANWIZLOGBY == '0':  # By Days
            keep = tools.get_date(days=-CONFIG.MAXWIZDATES[int(float(CONFIG.CLEANDAYS))])
            x = 0
            for line in lines:
                if len(line) >= 11 and str(line[1:11]) >= str(keep):
                    break
                x += 1
            newfile = lines[x:]
            tools.write_to_file(log_path, '\n'.join(newfile))
        elif CONFIG.CLEANWIZLOGBY == '1':  # By Size
            maxsize = CONFIG.MAXWIZSIZE[int(float(CONFIG.CLEANSIZE))] * 1024
            if os.path.exists(log_path) and os.path.getsize(log_path) >= maxsize:
                start = int(len(lines) / 2)
                newfile = lines[start:]
                tools.write_to_file(log_path, '\n'.join(newfile))
        elif CONFIG.CLEANWIZLOGBY == '2':  # By Lines
            maxlines = CONFIG.MAXWIZLINES[int(float(CONFIG.CLEANLINES))]
            if len(lines) > maxlines:
                start = len(lines) - int(maxlines / 2)
                newfile = lines[start:]
                tools.write_to_file(log_path, '\n'.join(newfile))

        CONFIG.set_setting('nextwizcleandate', next_when)
    except Exception:
        pass

def log_notify(title, message, times=2000, icon=CONFIG.ADDON_ICON, sound=False):
    try:
        xbmcgui.Dialog().notification(title, message, icon, int(times), sound)
    except Exception:
        pass

def grab_log(file=False, old=False, wizard=False):
    try:
        if wizard:
            log_path = _translate_path(CONFIG.WIZLOG)
            if os.path.exists(log_path):
                return log_path if file else tools.read_from_file(log_path)
            return False

        logsfound = []
        base = _translate_path(CONFIG.LOGPATH)
        try:
            for item in os.listdir(base):
                if os.path.basename(item).startswith('kodi') and item.endswith('.log'):
                    is_old = ('old' in item)
                    if (old and is_old) or (not old and not is_old):
                        logsfound.append(os.path.join(base, item))
        except Exception:
            pass

        if logsfound:
            logsfound.sort(key=lambda f: os.path.getmtime(f))
            return logsfound[-1] if file else tools.read_from_file(logsfound[-1])

        return False
    except Exception:
        return False

def upload_log():
    files = get_files()
    for item in files:
        filetype = item[0]
        if filetype == 'log':
            logname = os.path.basename(grab_log(file=True)) if grab_log(file=True) else "kodi.log"
            error = "Error posting the {0} file".format(logname)
            name = logname
        elif filetype == 'oldlog':
            logname = os.path.basename(grab_log(file=True, old=True)) if grab_log(file=True, old=True) else "kodi.old.log"
            error = "Error posting the {0} file".format(logname)
            name = logname
        elif filetype == 'wizlog':
            name = "wizard.log"
            error = "Error posting the {0} file".format(name)
        elif filetype == 'crashlog':
            name = "crash log"
            error = "Error posting the crashlog file"
        succes, data = read_log(item[1])
        if succes:
            content = clean_log(data)
            succes, result = post_log(content, name)
            if succes:
                msg = ("Post this url or scan QRcode for your [COLOR {0}]{1}[/COLOR],"
                       "together with a description of the problem:[CR][COLOR {2}]{3}[/COLOR]").format(
                       CONFIG.COLOR1, name, CONFIG.COLOR1, result)
                show_result(msg, result)
            else:
                show_result('{0}[CR]{1}'.format(error, result))
        else:
            show_result('{0}[CR]{1}'.format(error, result))

def get_files():
    logfiles = []
    kodilog = grab_log(file=True)
    old = grab_log(file=True, old=True)
    wizard = _translate_path(CONFIG.WIZLOG) if os.path.exists(_translate_path(CONFIG.WIZLOG)) else False

    if kodilog and os.path.exists(kodilog):
        logfiles.append(['log', kodilog])
    else:
        show_result("No log file found")

    if CONFIG.KEEPOLDLOG:
        if old and os.path.exists(old):
            logfiles.append(['oldlog', old])
        else:
            show_result("No old log file found")

    if CONFIG.KEEPWIZLOG:
        if wizard:
            logfiles.append(['wizlog', wizard])
        else:
            show_result("No wizard log file found")

    if CONFIG.KEEPCRASHLOG:
        crashlog_path = ''
        items = []
        if xbmc.getCondVisibility('system.platform.osx'):
            crashlog_path = os.path.join(os.path.expanduser('~'), 'Library/Logs/DiagnosticReports/')
            filematch = 'Kodi'
        elif xbmc.getCondVisibility('system.platform.ios'):
            crashlog_path = '/var/mobile/Library/Logs/CrashReporter/'
            filematch = 'Kodi'
        elif tools.platform() == 'linux':
            crashlog_path = os.path.expanduser('~')
            filematch = 'kodi_crashlog'
        elif tools.platform() == 'windows':
            log("Windows crashlogs are not supported, please disable this option in the addon settings")
            filematch = None
        elif tools.platform() == 'android':
            log("Android crashlogs are not supported, please disable this option in the addon settings")
            filematch = None
        else:
            filematch = None

        if crashlog_path and os.path.isdir(crashlog_path) and filematch:
            dirs, files = xbmcvfs.listdir(crashlog_path)
            for item in files:
                full = os.path.join(crashlog_path, item)
                if filematch in item and os.path.isfile(full):
                    items.append(full)
            if items:
                items.sort(key=lambda f: os.path.getmtime(f))
                lastcrash = items[-1]
                logfiles.append(['crashlog', lastcrash])
        if not items and CONFIG.KEEPCRASHLOG:
            log("No crashlog file found")

    return logfiles

def read_log(path):
    try:
        lf = xbmcvfs.File(path)
        content = lf.read()
        lf.close()
        if content:
            return True, content
        else:
            log('file is empty')
            return False, "File is Empty"
    except Exception as e:
        log('unable to read file: {0}'.format(e))
        return False, "Unable to Read File"

def clean_log(content):
    try:
        for pattern, repl in REPLACES:
            content = re.sub(pattern, repl, content)
        return content
    except Exception:
        return content

def post_log(data, name):
    params = {'poster': CONFIG.BUILDERNAME, 'content': data, 'syntax': 'text', 'expiration': 'week'}
    params = urlencode(params)
    try:
        page = LogURLopener().open(URL, params)
    except Exception as e:
        a = 'failed to connect to the server'
        log("{0}: {1}".format(a, str(e)), level=getattr(xbmc, "LOGERROR", 3))
        return False, a
    try:
        page_url = page.url.strip()
        log("URL for {0}: {1}".format(name, page_url))
        return True, page_url
    except Exception as e:
        a = 'unable to retrieve the paste url'
        log("{0}: {1}".format(a, str(e)), level=getattr(xbmc, "LOGERROR", 3))
        return False, a

# CURRENTLY NOT IN USE
def copy_to_clipboard(txt):
    import subprocess
    platform = tools.platform()
    if platform == 'windows':
        try:
            cmd = 'echo ' + txt.strip() + '|clip'
            return subprocess.check_call(cmd, shell=True)
        except Exception:
            pass
    elif platform == 'linux':
        try:
            from subprocess import Popen, PIPE
            p = Popen(['xsel', '-pi'], stdin=PIPE)
            p.communicate(input=txt)
        except Exception:
            pass
    else:
        pass

class LogURLopener(FancyURLopener):
    version = '{0}: {1}'.format(CONFIG.ADDON_ID, CONFIG.ADDON_VERSION)

def show_result(message, url=None):
    from resources.libs.gui import window
    dialog = xbmcgui.Dialog()
    if url:
        try:
            from resources.libs import qr
            fn = url.split('/')[-2]
            imagefile = qr.generate_code(url, fn)
            window.show_qr_code("loguploader.xml", imagefile, message)
            try:
                os.remove(imagefile)
            except Exception:
                pass
        except Exception as e:
            log(str(e), getattr(xbmc, "LOGINFO", 1))
            dialog.ok(CONFIG.ADDONTITLE, "[COLOR %s]%s[/COLOR]" % (CONFIG.COLOR2, message))
    else:
        dialog.ok(CONFIG.ADDONTITLE, "[COLOR %s]%s[/COLOR]" % (CONFIG.COLOR2, message))

def view_log_file():
    from resources.libs.gui import window
    mainlog = grab_log(file=True)
    oldlog = grab_log(file=True, old=True)
    wizlog = grab_log(file=True, wizard=True)

    choices = []
    logfiles = {
        'mainlog': "View {0}".format(os.path.basename(mainlog)) if mainlog else "",
        'oldlog': "View {0}".format(os.path.basename(oldlog)) if oldlog else "",
        'wizlog': "View {0}".format(os.path.basename(wizlog)) if wizlog else "",
    }

    if mainlog: choices.append(logfiles['mainlog'])
    if oldlog:  choices.append(logfiles['oldlog'])
    if wizlog:  choices.append(logfiles['wizlog'])

    dialog = xbmcgui.Dialog()
    if len(choices) > 0:
        which = dialog.select(CONFIG.ADDONTITLE, choices)
        if which == -1:
            log_notify('[COLOR {0}]View Log[/COLOR]'.format(CONFIG.COLOR1),
                       '[COLOR {0}]View Log Cancelled![/COLOR]'.format(CONFIG.COLOR2))
            return
        if which == 0 and mainlog:
            logtype = mainlog
        elif which == 1 and oldlog:
            logtype = oldlog
        elif which == 2 and wizlog:
            logtype = wizlog
        else:
            logtype = mainlog or oldlog or wizlog
    else:
        log_notify('[COLOR {0}]View Log[/COLOR]'.format(CONFIG.COLOR1),
                   '[COLOR {0}]No Log File Found![/COLOR]'.format(CONFIG.COLOR2))
        return

    window.show_log_viewer("Viewing Log File", log_file=logtype, ext_buttons=True)

def swap_debug():
    import threading
    new = '"debug.showloginfo"'
    query = '{{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{{"setting":{0}}}, "id":1}}'.format(new)
    response = xbmc.executeJSONRPC(query)
    log("Debug Logging Get Settings: {0}".format(str(response)))
    if 'false' in response:
        value = 'true'
        threading.Thread(target=_dialog_watch).start()
        xbmc.sleep(200)
        query = '{{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{{"setting":{0},"value":{1}}}, "id":1}}'.format(new, value)
        response = xbmc.executeJSONRPC(query)
        log_notify(CONFIG.ADDONTITLE, '[COLOR {0}]Debug Logging:[/COLOR] [COLOR {1}]Enabled[/COLOR]'.format(CONFIG.COLOR1, CONFIG.COLOR2))
        log("Debug Logging Set Settings: {0}".format(str(response)))
    elif 'true' in response:
        value = 'false'
        threading.Thread(target=_dialog_watch).start()
        xbmc.sleep(200)
        query = '{{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{{"setting":{0},"value":{1}}}, "id":1}}'.format(new, value)
        response = xbmc.executeJSONRPC(query)
        log_notify(CONFIG.ADDONTITLE, '[COLOR {0}]Debug Logging:[/COLOR] [COLOR {1}]Disabled[/COLOR]'.format(CONFIG.COLOR1, CONFIG.COLOR2))
        log("Debug Logging Set Settings: {0}".format(str(response)))

def _dialog_watch():
    x = 0
    while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 100:
        x += 1
        xbmc.sleep(100)
    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
        xbmc.executebuiltin('SendClick(yesnodialog, 11)')
        return True
    else:
        return False

def error_list(file):
    errors = []
    content = tools.read_from_file(file) if os.path.exists(file) else ""
    b = content.replace('\n', '[CR]').replace('\r', '')
    match = re.compile(
        "-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--"
    ).findall(b)
    for item in match:
        errors.append(item)
    return errors

def error_checking(log=None, count=None, last=None):
    errors = []
    error1 = []
    error2 = []
    if log is None:
        curr = grab_log(file=True)
        old = grab_log(file=True, old=True)
        if not old and not curr:
            if count is None:
                log_notify('[COLOR {0}]View Error Log[/COLOR]'.format(CONFIG.COLOR1),
                           '[COLOR {0}]No Log File Found![/COLOR]'.format(CONFIG.COLOR2))
                return
            else:
                return 0
        if curr:
            error1 = error_list(curr)
        if old:
            error2 = error_list(old)
        if len(error2) > 0:
            for item in error2:
                errors = [item] + errors
        if len(error1) > 0:
            for item in error1:
                errors = [item] + errors
    else:
        error1 = error_list(log)
        if len(error1) > 0:
            for item in error1:
                errors = [item] + errors

    if count is not None:
        return len(errors)
    elif len(errors) > 0:
        from resources.libs.gui import window
        if last is None:
            i = 0
            string = ''
            for item in errors:
                i += 1
                string += "[B][COLOR red]ERROR NUMBER {0}:[/B][/COLOR] {1}\n".format(
                    str(i), item.replace(CONFIG.HOME, '/').replace('                                        ', ''))
            window.show_log_viewer("Viewing Errors in Log", string)
        else:
            string = "[B][COLOR red]Last Error in Log:[/B][/COLOR] {0}\n".format(
                errors[0].replace(CONFIG.HOME, '/').replace('                                        ', ''))
            window.show_log_viewer("Viewing Last Error in Log", string)
    else:
        log_notify('[COLOR {0}]View Error Log[/COLOR]'.format(CONFIG.COLOR1),
                   '[COLOR {0}]No Errors Found![/COLOR]'.format(CONFIG.COLOR2))
