# -*- coding: utf-8 -*-

import sys
import os
import traceback
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')

# Pfad ermitteln (Matrix/Nexus/Omega)
try:
    import xbmcvfs
    ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
except Exception:
    ADDON_PATH = ADDON.getAddonInfo('path')

ICON = os.path.join(ADDON_PATH, 'resources', 'icon.png')
FANART = os.path.join(ADDON_PATH, 'resources', 'fanart.jpg')

# Sichere Log-Level (Kodi 19+ hat kein LOGNOTICE mehr)
try:
    LOGINFO = xbmc.LOGINFO
except Exception:
    LOGINFO = 1
try:
    LOGERROR = xbmc.LOGERROR
except Exception:
    LOGERROR = 3
try:
    LOGWARNING = xbmc.LOGWARNING
except Exception:
    LOGWARNING = 2


def log(msg, lvl=LOGINFO):
    try:
        xbmc.log(f"[{ADDON_ID}] {msg}", lvl)
    except Exception:
        pass


def notify(msg, heading=ADDON_NAME, time=4000):
    try:
        xbmcgui.Dialog().notification(heading, msg, ICON, time)
    except Exception:
        pass


def get_handle():
    try:
        return int(sys.argv[1])
    except Exception:
        return -1


def get_querystring():
    if len(sys.argv) > 2 and sys.argv[2]:
        s = sys.argv[2]
        return s[1:] if s.startswith('?') else s
    return ""


def fallback_menu(handle):
    try:
        li = xbmcgui.ListItem(label="Start MegaWizard")
        li.setArt({"icon": ICON, "thumb": ICON, "fanart": FANART})
        url = f"{sys.argv[0]}?{urllib.parse.urlencode({'action': 'run'})}"
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True)
    except Exception:
        pass


def preflight_note_requests():
    try:
        import requests  # noqa: F401
    except Exception:
        log("'requests' nicht gefunden – falls der Router es benötigt, erscheint ein Dialog.", LOGWARNING)


if __name__ == "__main__":
    handle = get_handle()
    qs = get_querystring()
    preflight_note_requests()

    try:
        from resources.libs.common import router
    except Exception:
        log("Import von router fehlgeschlagen:\n" + traceback.format_exc(), LOGERROR)
        notify("Fehler beim Laden (router). Details im Log.")
        fallback_menu(handle)
    else:
        try:
            dispatcher = router.Router()
            dispatcher.dispatch(handle, qs)
        except ModuleNotFoundError as e:
            if "requests" in str(e).lower():
                notify("Fehlende Abhängigkeit: 'script.module.requests' wird benötigt.")
            log("Laufzeitfehler (Module):\n" + traceback.format_exc(), LOGERROR)
            notify("Fehler beim Ausführen. Details im Log.")
            fallback_menu(handle)
        except Exception:
            log("Unerwarteter Fehler:\n" + traceback.format_exc(), LOGERROR)
            notify("Unerwarteter Fehler. Details im Log.")
            fallback_menu(handle)
