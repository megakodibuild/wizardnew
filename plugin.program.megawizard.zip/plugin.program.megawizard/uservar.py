import xbmcaddon
import os

#########################################################
#         Global Variables - DON'T EDIT!!!              #
#########################################################
ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
PATH = xbmcaddon.Addon().getAddonInfo('path')
ART = os.path.join(PATH, 'resources', 'media')
#########################################################

#########################################################
#        User Edit Variables                            #
#########################################################
ADDONTITLE = '[COLOR limegreen][B]MK[/B][/COLOR]Wizard'
BUILDERNAME = 'MK Wizard '
EXCLUDES = [ADDON_ID, 'plugin.program.megawizard']

# Text File with build info in it.
BUILDFILE = 'https://megakodibuild.github.io/megakodi/text/autobuildsnew.txt'
# How often you would like it to check for build updates in days
# 0 being every startup of kodi
UPDATECHECK = 0
# Text File with apk info in it.  Leave as 'http://' to ignore
APKFILE = 'http://'
# Text File with Youtube Videos urls.  Leave as 'http://' to ignore
YOUTUBETITLE = ''
YOUTUBEFILE = 'http://'
# Text File for addon installer.  Leave as 'http://' to ignore
ADDONFILE = 'http://'
# Text File for advanced settings.  Leave as 'http://' to ignore
ADVANCEDFILE = 'http://'
#########################################################

#########################################################
#        Theming Menu Items                             #
#########################################################
ICONBUILDS   = os.path.join(ART, 'builds.png')
ICONMAINT    = os.path.join(ART, 'maintenance.png')
ICONSPEED    = os.path.join(ART, 'speed.png')
ICONAPK      = os.path.join(ART, 'apkinstaller.png')
ICONADDONS   = os.path.join(ART, 'addoninstaller.png')
ICONYOUTUBE  = os.path.join(ART, 'youtube.png')
ICONSAVE     = os.path.join(ART, 'savedata.png')
ICONTRAKT    = os.path.join(ART, 'keeptrakt.png')
ICONREAL     = os.path.join(ART, 'keepdebrid.png')
ICONLOGIN    = os.path.join(ART, 'keeplogin.png')
ICONCONTACT  = os.path.join(ART, 'information.png')
ICONSETTINGS = os.path.join(ART, 'settings.png')

HIDESPACERS = 'No'
SPACER = '='

COLOR1 = 'limegreen'
COLOR2 = 'white'
THEME1 = u'[COLOR {color1}][I]([COLOR {color1}][B]MK [/B][/COLOR][COLOR {color2}]Wizard[COLOR {color1}]) [/I][/COLOR] [COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2)
THEME2 = u'[COLOR {color1}]{{}}[/COLOR]'.format(color1=COLOR1)
THEME3 = u'[COLOR {color1}]{{}}[/COLOR]'.format(color1=COLOR1)
THEME4 = u'[COLOR {color1}]Current Build: [/COLOR] [COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2)
THEME5 = u'[COLOR {color1}]Current Theme: [/COLOR] [COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2)

# Message for Contact Page
HIDECONTACT = 'No'
CONTACT = 'Thank you for choosing MK Wizard.\nContact us on http://adri-kodi.com'
CONTACTICON = 'http://'
CONTACTFANART = 'http://_'
#########################################################

#########################################################
#        Auto Update For Those With No Repo             #
#########################################################
AUTOUPDATE = 'Yes'
#########################################################

#########################################################
#        Auto Install Repo If Not Installed             #
#########################################################
AUTOINSTALL = 'No'
REPOID = 'repository.openwizard'
REPOADDONXML = 'https://'
REPOZIPURL = 'https://'
#########################################################

#########################################################
#        Notification Window                            #
#########################################################
# WICHTIG: 'ENABLE' wird von config.py erwartet
ENABLE = 'Yes'
# Alias, falls irgendwo ENABLE_NOTIFICATION verwendet wird
ENABLE_NOTIFICATION = ENABLE

NOTIFICATION = 'http://'
HEADERTYPE = 'Text'
FONTHEADER = 'Font14'
HEADERMESSAGE = '[COLOR limegreen][B]MK[/B][/COLOR]Wizard'
HEADERIMAGE = 'http://'
FONTSETTINGS = 'Font13'
BACKGROUND = 'http://'
#########################################################
